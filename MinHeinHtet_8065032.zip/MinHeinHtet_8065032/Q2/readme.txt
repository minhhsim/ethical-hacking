**Author: Min Hein Htet**

## To replicate this exercise:

1. Start by running your Metasploitable 2 VM and retrieving the IP address of your Metasploitable 2 instance.

2. Once Metasploitable 2 is running, open a web browser on your Kali Linux machine and access the DVWA (Damn Vulnerable Web Application) using the following link:
   ```
   http://[META 2 IP ADDRESS]/
   ```

3. Log in to DVWA with the following credentials:
   - Username: `admin`
   - Password: `password`

4. Set the DVWA security setting to 'Low' and proceed to the SQL Injection section.

## Notes:

1. The images and text files provided show the various SQL injection commands used to retrieve information about the users in the database.