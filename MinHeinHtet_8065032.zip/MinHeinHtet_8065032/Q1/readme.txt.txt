Author: Min Hein Htet
Overview


When developing the backdoor program, my main goal was to ensure usability while adhering to the requirements of the assignment. The key considerations included how to maintain the connection, handle message termination, and allow the program to gracefully exit.

**Socket Communication:

The program uses sockets to establish a connection between the victim's Ubuntu machine and the attacker's Kali machine. This connection is initiated by the victim machine using the socket module, which then constantly listens for incoming commands from the attacker. This design allows the attacker to send commands to the victim's machine and receive the output of those commands back.

To avoid issues with message termination, the program uses a simple while True loop that keeps the connection open until a specific termination signal, in this case, the & symbol, is received. This ensures that the program can continuously accept and process commands until explicitly told to stop. The use of the recv() method allows the program to read incoming data, which is then decoded and processed accordingly.

**Command Execution and Handling:

The code employs the subprocess module to execute the received commands on the victim's machine. This module was chosen because it allows the execution of system-level commands and can capture both standard output and error output, which is then sent back to the attacker. By using subprocess.check_output(), the program can execute non-interactive commands and return their output. This is particularly useful in a backdoor scenario where the attacker needs to execute various system commands remotely.

The program also handles the cd command separately to change directories, updating the current path variable accordingly. This is an important usability feature, as it allows the attacker to navigate the file system of the victim's machine during the session.       

To run the program:

    On your Kali Linux, run the following command:
    nc -v -l -p 5555

    On your Ubuntu, navigate to the this folder (Q1) and run the following command:
    python3 backdoor.py

    Go back to your Kali Linux and start entering the commands. The available commands can be found below.

    To end the program, enter & on your Kali Linux.

Notes:

    Ensure the IP address in "kali_ip" variable is set up to match your Kali IP.

    Ensure Ubuntu and Kali Linux are sharing the same NAT Network.

Supported Commands:

    Non-interactive linux commands such as ls, pwd, cat <text.txt>...

    Changing directories with cd <dir>

Note: Commands to open text editors such as gedit will open in the target PC (Ubuntu) and can only be closed on their end!