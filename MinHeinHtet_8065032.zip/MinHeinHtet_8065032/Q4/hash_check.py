import hashlib

voucher_code = '7a2c28ed9a171ffdf6534c32d922c639'

hash = hashlib.md5(b'tf8065032#[').hexdigest()

print("Voucher Code:", voucher_code)
print ("Calculated Hash:", hash)
